# Service Sjekkliste - The Gathering
## Setup and Usage Guide

## 🎯 Overview

This PWA (Progressive Web App) provides shift-based task reminders for The Gathering event staff. Workers can:
- Select their shift (Day/Evening/Night)
- Get reminders before their shift starts
- Receive hourly notifications with tasks specific to their shift
- Track completed tasks with checkboxes

---

## 📋 Google Sheet Setup

### 1. Create Your Google Sheet

Your Google Sheet must have these **exact column headers** (case-insensitive):

| Column | Description | Required | Format |
|--------|-------------|----------|--------|
| **Enabled** | TRUE/FALSE to enable/disable task | Yes | TRUE or FALSE |
| **Category** | Task category (for organization) | Yes | Text |
| **Task** | Description of the task | Yes | Text |
| **Day Time** | When to do task in day shift | No | HH:MM (24-hour) |
| **Evening Time** | When to do task in evening shift | No | HH:MM (24-hour) |
| **Night Time** | When to do task in night shift | No | HH:MM (24-hour) |

### 2. Example Sheet Structure

```
Enabled | Category    | Task                      | Day Time | Evening Time | Night Time
--------|-------------|---------------------------|----------|--------------|------------
TRUE    | Crew Area   | Check coffee supplies     | 09:00    | 17:00        | 01:00
TRUE    | Toilets     | Check supplies            | 10:00    | 18:00        | 02:00
TRUE    | Security    | Walkthrough               | 11:00    | 19:00        | 03:00
FALSE   | Kitchen     | Restock (DISABLED)        | 12:00    | 20:00        | 04:00
TRUE    | General     | Day shift only            | 14:00    |              |
TRUE    | General     | Evening/Night only        |          | 22:00        | 06:00
```

### 3. Publishing Your Sheet

1. In Google Sheets, go to **File → Share → Publish to web**
2. Choose **Entire Document** and **Comma-separated values (.csv)**
3. Click **Publish**
4. Copy the URL (it will look like: `https://docs.google.com/spreadsheets/d/SHEET_ID/...`)
5. Extract the `SHEET_ID` from the URL
6. Update `GOOGLE_SHEET_ID` in `index.html` (line 302)

### 4. Getting the Sheet GID (if using multiple sheets)

1. Look at the URL when viewing your sheet
2. Find `#gid=0` (or another number) at the end
3. Update `GOOGLE_SHEET_GID` in `index.html` (line 303)

**Default:** If you only have one sheet, the GID is `0`

---

## ⚙️ Configuration

### Shift Times

Default shift times are:
- **Day Shift:** 08:00 - 16:00
- **Evening Shift:** 16:00 - 00:00 (midnight)
- **Night Shift:** 00:00 - 08:00

To change these, edit lines 309-313 in `index.html`:

```javascript
const SHIFTS = {
    day: { name: 'Dag', start: '08:00', end: '16:00', column: 'Day Time' },
    evening: { name: 'Kveld', start: '16:00', end: '00:00', column: 'Evening Time' },
    night: { name: 'Natt', start: '00:00', end: '08:00', column: 'Night Time' }
};
```

### Notification Timing

- **Shift start reminders:** User can choose 15, 30, or 60 minutes before shift
- **Hourly task reminders:** Sent **10 minutes before** the hour (at XX:50)

To change the hourly reminder timing, edit the notification scheduling logic around line 887 in `index.html`.

---

## 📱 Installation & Usage

### For iOS Users (iPhone/iPad)

1. Open the website in **Safari**
2. Tap the **Share** button (square with arrow)
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **Add**
5. ⚠️ **IMPORTANT:** Notifications ONLY work when added to home screen

### For Android Users

1. Open the website in **Chrome**
2. Tap the menu (three dots)
3. Tap **"Add to Home Screen"** or **"Install app"**
4. Tap **Add** or **Install**

### First Time Setup

1. Wait for the app to load data from Google Sheets
2. Go to the **🔔 Påminnelser** section
3. Select your shift (Day/Evening/Night)
4. Enable desired reminders:
   - ☐ Remind me before shift starts
   - ☐ Hourly task reminders
5. Tap **"Aktiver påminnelser"** to grant notification permissions

---

## 🔔 How Notifications Work

### Shift Start Reminder
- One notification sent X minutes before your shift starts (you choose 15/30/60)
- Example: If you work Day shift (starts 08:00) and chose 15 minutes, you get a reminder at 07:45
- Automatically schedules for next day after firing

### Hourly Task Reminders
- Sent **10 minutes before each hour** (at XX:50)
- Only sent during your active shift hours
- Shows all tasks scheduled for the next hour in your shift
- Example: At 10:50, you receive: "Oppgaver kl 11:00: • Check coffee • Security walkthrough"

### Example Timeline (Day Shift Worker)

```
07:45 → 🔔 "Skiftet ditt starter snart! Dag-skift starter om 15 minutter"
08:50 → 🔔 "Oppgaver kl 09:00: • Check coffee supplies • Main entrance walkthrough"
09:50 → 🔔 "Oppgaver kl 10:00: • Check toilet supplies • Check lighting"
10:50 → 🔔 "Oppgaver kl 11:00: • Refill water • Security walkthrough • Restock snacks"
...continues until shift ends at 16:00
```

---

## 🛠️ Managing Tasks During Event

### To Disable a Task
In your Google Sheet, change the **Enabled** column from `TRUE` to `FALSE`

### To Change Task Time
Simply edit the time in the appropriate shift column (Day Time / Evening Time / Night Time)

### To Add New Task
Add a new row with:
- `TRUE` in Enabled column
- Category and Task descriptions
- Times for applicable shifts

### To Remove Task from One Shift
Leave that shift's time column empty

### Updating the App
1. Make changes in Google Sheet
2. In the app, tap **"↻ Oppdater data"**
3. Confirm reload

Changes will also sync automatically when workers restart the app.

---

## ⚠️ Important Limitations

### iOS Restrictions
- App MUST be added to home screen for notifications to work
- App must be running (can be backgrounded, but not force-closed)
- If user force-closes the app, no notifications until they reopen it

### Android
- More flexible - notifications work even when app is closed
- Still recommend adding to home screen for best experience

### Network Requirements
- Initial load requires internet connection
- After first load, app works offline with cached data
- Data updates require internet connection

---

## 🐛 Troubleshooting

### "No notifications appearing"
1. Check notification permissions in browser/phone settings
2. Verify shift is selected
3. Ensure at least one reminder type is enabled
4. On iOS: Verify app is added to home screen
5. Check that current time is within shift hours (for hourly reminders)

### "No tasks in notifications"
1. Verify Google Sheet has tasks with correct times
2. Check that tasks are enabled (TRUE in Enabled column)
3. Verify time format is HH:MM (e.g., 09:00, not 9:00 AM)
4. Refresh data with "↻ Oppdater data" button

### "Can't load data from Google Sheet"
1. Verify sheet is published to web as CSV
2. Check GOOGLE_SHEET_ID in index.html is correct
3. Check internet connection
4. Try refreshing the page

### "Checkboxes not saving"
1. Check browser localStorage is enabled
2. Don't use private/incognito mode
3. Clear browser cache and reload

---

## 📁 File Structure

```
/
├── index.html              # Main application file
├── manifest.json           # PWA manifest
├── service-worker.js       # Service worker for offline support
├── example-sheet-template.csv  # Template for Google Sheet
├── README.md              # This file
└── icons/                 # App icons (you need to create these)
    ├── icon-72x72.png
    ├── icon-96x96.png
    ├── icon-128x128.png
    ├── icon-144x144.png
    ├── icon-152x152.png
    ├── icon-192x192.png
    ├── icon-384x384.png
    └── icon-512x512.png
```

---

## 🎨 Creating Icons

You need to create app icons in these sizes:
- 72x72, 96x96, 128x128, 144x144, 152x152, 192x192, 384x384, 512x512

Quick method:
1. Create a 512x512 PNG with your logo/design
2. Use an online tool like https://realfavicongenerator.net/
3. Generate all sizes
4. Place in `/icons/` folder

---

## 🚀 Deployment to GitHub Pages

1. Create a new repository on GitHub
2. Upload all files to the repository
3. Go to **Settings → Pages**
4. Under "Source", select your branch (usually `main`)
5. Save and wait a few minutes
6. Your app will be available at `https://[username].github.io/[repository-name]/`

---

## 📝 Customization

### Changing Colors
Edit the CSS in `index.html` (lines 24-295):
- Primary color: `#667eea` (search and replace)
- Gradient: lines 33-34

### Changing Language
All text strings are in Norwegian. To translate:
1. Search for Norwegian text in `index.html`
2. Replace with your language
3. Update `<html lang="no">` to your language code

### Adding More Shifts
Edit the `SHIFTS` object (lines 309-313) and add new shift options to the dropdown.

---

## 💡 Tips for Event Supervisors

1. **Test before the event:** Set up the system a week early and test with volunteers
2. **Create backup:** Keep a PDF version of the checklist as backup
3. **Share instructions:** Print QR code to the app and instructions for adding to home screen
4. **Monitor usage:** Check with workers on Day 1 to ensure notifications are working
5. **Be flexible:** You can adjust task times in real-time by editing the Google Sheet

---

## 🆘 Support

For issues or questions during The Gathering event, contact your technical supervisor.

---

## 📄 License

Created for The Gathering event. Free to use and modify.
